using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ProSim DataRef Monitor")]
[assembly: AssemblyDescription("Monitor selected ProSim DataRefs via SDK")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ProSimDataRefMonitor")]
[assembly: AssemblyCopyright("© 2025")]
[assembly: ComVisible(false)]
[assembly: Guid("6f36fba7-5c3b-4b2f-9d61-9e0e5f35a8e2")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
