using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProSimDataRefMonitor
{
    public partial class MainForm : Form
    {
        private IProSimClient _client;
        private CancellationTokenSource _cts;

        public MainForm()
        {
            InitializeComponent();
            grid.AllowUserToAddRows = false;
            grid.AllowUserToResizeRows = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.MultiSelect = true;

            LoadCatalog();
        }

        private async void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                btnConnect.Enabled = false;
                var host = txtIp.Text.Trim(); // e.g. 127.0.0.1
                _client?.Dispose();

                _client = new SdkClient(host);

                await _client.ConnectAsync();
                lblStatus.Text = $"Connected via {_client.ModeName}";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Connection error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblStatus.Text = "Disconnected";
            }
            finally
            {
                btnConnect.Enabled = true;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int idx = grid.Rows.Add();
            grid.Rows[idx].Cells[0].Value = ""; // prompt user to pick from catalog (autocomplete)
            grid.Rows[idx].Cells[1].Value = "";
            grid.Rows[idx].Cells[2].Value = "";
            grid.Rows[idx].Cells[3].Value = "";
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow r in grid.SelectedRows.Cast<DataGridViewRow>())
            {
                grid.Rows.Remove(r);
            }
        }

        private async void btnStart_Click(object sender, EventArgs e)
        {
            if (_client == null)
            {
                MessageBox.Show(this, "Please connect first.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var names = grid.Rows.Cast<DataGridViewRow>()
                .Select(r => (r.Cells[0].Value?.ToString() ?? string.Empty).Trim())
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Take(30)
                .ToArray();

            if (names.Length == 0)
            {
                MessageBox.Show(this, "Add DataRefs in the first column (use autocomplete).", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Fill Type/Unit columns from catalog before starting
            foreach (DataGridViewRow row in grid.Rows)
            {
                var name = row.Cells[0].Value?.ToString();
                if (string.IsNullOrWhiteSpace(name)) continue;
                var meta = _catalog?.FirstOrDefault(x => string.Equals(x.Name, name, StringComparison.OrdinalIgnoreCase));
                if (meta != null)
                {
                    row.Cells[2].Value = meta.Type ?? "";
                    row.Cells[3].Value = meta.Unit ?? "";
                }
            }

            btnStart.Enabled = false;
            btnStop.Enabled = true;
            _cts = new CancellationTokenSource();

            await _client.StartAsync(names, OnValue);
            lblStatus.Text = $"Monitoring {names.Length} refs";
        }

        private async void btnStop_Click(object sender, EventArgs e)
        {
            btnStop.Enabled = false;
            try
            {
                await _client?.StopAsync();
                _cts?.Cancel();
                lblStatus.Text = "Stopped";
            }
            finally
            {
                btnStart.Enabled = true;
            }
        }

        private void OnValue(string name, ProSimValue value)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new Action<string, ProSimValue>(OnValue), name, value);
                return;
            }

            foreach (DataGridViewRow row in grid.Rows)
            {
                var refName = row.Cells[0].Value?.ToString();
                if (string.Equals(refName, name, StringComparison.OrdinalIgnoreCase))
                {
                    row.Cells[1].Value = value.ValueAsString;
                    break;
                }
            }
        }

        // ==== Catalog loading & autocomplete ====
        private class DataRefEntry
        {
            public string Name { get; set; }
            public string Type { get; set; }
            public string Unit { get; set; }
            public bool CanRead { get; set; }
            public bool CanWrite { get; set; }
            public string Description { get; set; }
        }

        private List<DataRefEntry> _catalog;

        private void LoadCatalog()
        {
            try
            {
                var path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ProSimDataRefs.xml");
                if (!System.IO.File.Exists(path)) { _catalog = new List<DataRefEntry>(); return; }
                var doc = System.Xml.Linq.XDocument.Load(path);
                _catalog = doc.Root
                    .Elements("DataRef")
                    .Select(x => new DataRefEntry
                    {
                        Name = (string)x.Attribute("name"),
                        Type = (string)x.Attribute("type"),
                        Unit = (string)x.Attribute("unit"),
                        CanRead = string.Equals((string)x.Attribute("canRead"), "true", StringComparison.OrdinalIgnoreCase),
                        CanWrite = string.Equals((string)x.Attribute("canWrite"), "true", StringComparison.OrdinalIgnoreCase),
                        Description = (string)x.Element("Description") ?? ""
                    })
                    .Where(e => !string.IsNullOrWhiteSpace(e.Name))
                    .OrderBy(e => e.Name)
                    .ToList();
            }
            catch
            {
                _catalog = new List<DataRefEntry>();
            }
        }

        private void grid_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (grid.CurrentCell.ColumnIndex != 0) return; // only for DataRef column
            var tb = e.Control as TextBox;
            if (tb == null) return;

            var ac = new AutoCompleteStringCollection();
            if (_catalog != null && _catalog.Count > 0)
            {
                ac.AddRange(_catalog.Select(c => c.Name).ToArray());
            }
            tb.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            tb.AutoCompleteSource = AutoCompleteSource.CustomSource;
            tb.AutoCompleteCustomSource = ac;
        }
    }
}
