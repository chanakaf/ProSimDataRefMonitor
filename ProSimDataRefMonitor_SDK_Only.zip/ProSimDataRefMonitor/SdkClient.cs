using System;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace ProSimDataRefMonitor
{
    public sealed class SdkClient : IProSimClient
    {
        private readonly string _host;
        private object _sdk;
        private MethodInfo _connectMethod;
        private MethodInfo _subscribeMethod;
        private MethodInfo _unsubscribeAllMethod;
        private Action<string, ProSimValue> _onValue;

        public string ModeName => "SDK";

        public SdkClient(string host)
        {
            _host = host;
        }

        public static bool IsSdkAvailable()
        {
            try
            {
                Assembly asm = Assembly.Load("ProSimSDK");
                return asm != null;
            }
            catch { return false; }
        }

        public Task ConnectAsync()
        {
            Assembly sdkAsm = null;
            try { sdkAsm = Assembly.Load("ProSimSDK"); }
            catch (Exception)
            {
                var path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ProSimSDK.dll");
                if (!System.IO.File.Exists(path)) throw;
                sdkAsm = Assembly.LoadFrom(path);
            }
            if (sdkAsm == null) throw new InvalidOperationException("ProSimSDK.dll not found.");

            var typeNames = new[]
            {
                "ProSimSDK.ProSim",
                "ProSimSDK.ProSim737",
                "ProSimSDK.Client"
            };
            Type sdkType = typeNames
                .Select(n => sdkAsm.GetType(n, throwOnError: false, ignoreCase: true))
                .FirstOrDefault(t => t != null);

            if (sdkType == null)
                throw new InvalidOperationException("Could not find a known client type in ProSimSDK.dll. Please update SdkClient.cs with the correct type names.");

            _sdk = Activator.CreateInstance(sdkType);

            _connectMethod = sdkType.GetMethod("Connect", new[] { typeof(string) })
                             ?? sdkType.GetMethod("ConnectTo", new[] { typeof(string) });
            _subscribeMethod = sdkType.GetMethod("SubscribeDataRef", BindingFlags.Public | BindingFlags.Instance)
                               ?? sdkType.GetMethod("Subscribe", BindingFlags.Public | BindingFlags.Instance);
            _unsubscribeAllMethod = sdkType.GetMethod("UnsubscribeAll")
                                     ?? sdkType.GetMethod("Dispose");

            if (_connectMethod == null)
                throw new InvalidOperationException("Could not find Connect(host) in ProSimSDK. Update SdkClient.cs to match your SDK API.");

            _connectMethod.Invoke(_sdk, new object[] { _host });
            return Task.CompletedTask;
        }

        public Task StartAsync(string[] dataRefs, Action<string, ProSimValue> onValue)
        {
            _onValue = onValue;
            if (_subscribeMethod == null)
                throw new InvalidOperationException("Subscribe method not bound.");

            foreach (var name in dataRefs)
            {
                try
                {
                    var handler = new Action<string, object>((n, v) =>
                    {
                        var kind = GuessKind(v);
                        _onValue?.Invoke(n, new ProSimValue(kind, v));
                    });
                    _subscribeMethod.Invoke(_sdk, new object[] { name, handler });
                }
                catch (TargetParameterCountException)
                {
                    _subscribeMethod.Invoke(_sdk, new object[] { name });
                }
                catch (ArgumentException)
                {
                    _subscribeMethod.Invoke(_sdk, new object[] { name });
                }
            }
            return Task.CompletedTask;
        }

        public Task StopAsync()
        {
            try { _unsubscribeAllMethod?.Invoke(_sdk, new object[] { }); }
            catch { }
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            try { StopAsync().GetAwaiter().GetResult(); }
            catch { }
        }

        private static ProSimValueKind GuessKind(object v)
        {
            if (v is bool) return ProSimValueKind.Bool;
            if (v is int || v is long) return ProSimValueKind.Int;
            if (v is double || v is float || v is decimal) return ProSimValueKind.Double;
            if (v is string) return ProSimValueKind.String;
            return ProSimValueKind.Unknown;
        }
    }
}
